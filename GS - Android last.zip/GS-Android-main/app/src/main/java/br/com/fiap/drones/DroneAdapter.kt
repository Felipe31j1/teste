package br.com.fiap.drones

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

class DroneAdapter (
    private val myList: List<String>
        ) : RecyclerView.Adapter<DroneAdapter.MyViewHolder>(){

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DroneAdapter.MyViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.drone_item, parent, false)
        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: DroneAdapter.MyViewHolder, position: Int) {
        TODO("Not yet implemented")
    }

    override fun getItemCount(): Int {
        TODO("Not yet implemented")
    }

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

}
