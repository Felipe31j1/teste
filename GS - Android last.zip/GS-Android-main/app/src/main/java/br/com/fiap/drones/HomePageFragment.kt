package br.com.fiap.drones

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.navigation.ui.NavigationUI.setupActionBarWithNavController
import br.com.fiap.drones.databinding.FragmentHomePageBinding

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER

class HomePageFragment : Fragment() {
    lateinit var binding:FragmentHomePageBinding
    lateinit var navController: NavController

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentHomePageBinding.inflate(
            inflater,
            container,
            false
        )
        return binding.root
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupViews()
    }

    private fun setupViews() {
//        navController = Navigation.findNavController(this, R.id.fragmentHomepage)
//        setupActionBarWithNavController(navController)

        binding.bottomMenuView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.menuAccount -> {
                    navController.navigate(R.id.action_homePageFragment_to_accountFragment)
                    true
                }

                else -> false
            }


        }

        binding.bottomMenuView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.menuHome -> {
                    navController.navigate(R.id.action_global_homePageFragment)
                    true
                }

                else -> false
            }


        }

        binding.bottomMenuView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.menuDrone -> {
                    navController.navigate(R.id.action_homePageFragment_to_listFragment)
                    true
                }

                else -> false
            }


        }

        binding.bottomMenuView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.menuConfig -> {
                    navController.navigate(R.id.action_homePageFragment_to_settingsFragment)
                    true
                }

                else -> false
            }


        }
    }
}