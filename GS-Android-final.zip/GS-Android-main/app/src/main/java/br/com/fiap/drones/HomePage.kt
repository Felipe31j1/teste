package br.com.fiap.drones

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import br.com.fiap.drones.databinding.ActivityHomePageBinding


class HomePage : AppCompatActivity() {

    lateinit var binding: ActivityHomePageBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomePageBinding.inflate(layoutInflater)
        setContentView(binding.root)



    }

}
