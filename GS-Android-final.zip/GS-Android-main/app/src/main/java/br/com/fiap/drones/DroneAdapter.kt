import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import br.com.fiap.drones.R
import br.com.fiap.drones.model.Drone

class DroneAdapter( private val droneList: List<Drone>) :
    RecyclerView.Adapter<DroneAdapter.DroneViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DroneViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.drone_item, parent, false)
        return DroneViewHolder(view)
    }

    override fun onBindViewHolder(holder: DroneViewHolder, position: Int) {
        val drone = droneList[position]

        holder.numeroDroneTextView.text = drone.numeroDrone
        holder.descricaoTextView.text = drone.descricao
        holder.dadosTextView.text = drone.dados
        holder.dataAddTextView.text = drone.dataAdd
        holder.licencaTextView.text = drone.numId
    }

    override fun getItemCount(): Int {
        return droneList.size
    }

    inner class DroneViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val numeroDroneTextView: TextView = itemView.findViewById(R.id.numeroDrone)
        val descricaoTextView: TextView = itemView.findViewById(R.id.descricao)
        val dadosTextView: TextView = itemView.findViewById(R.id.dados)
        val dataAddTextView: TextView = itemView.findViewById(R.id.data_Add)
        val licencaTextView: TextView = itemView.findViewById(R.id.licenca)
    }
}
