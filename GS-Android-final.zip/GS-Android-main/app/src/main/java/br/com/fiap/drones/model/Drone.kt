package br.com.fiap.drones.model

data class Drone (
    val numeroDrone: String,
    val descricao: String,
    val dados: String,
    val dataAdd: String,
    val numId: String,

    )
